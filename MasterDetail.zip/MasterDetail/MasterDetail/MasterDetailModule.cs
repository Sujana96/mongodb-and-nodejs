﻿using Prism.Modularity;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDetail
{
    public class MasterDetailModule : IModule
    {
        private readonly IRegionViewRegistry regionViewRegistry;

        public MasterDetailModule(IRegionViewRegistry registry)
        {
            this.regionViewRegistry = registry;
        }

        public void Initialize()
        {
            regionViewRegistry.RegisterViewWithRegion("MasterRegion", typeof(Views.MasterView));
            regionViewRegistry.RegisterViewWithRegion("DetailRegion", typeof(Views.DetailView));

           
        }
    }
}
