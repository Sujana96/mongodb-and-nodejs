﻿using Prism.Commands;
using SimpleExampleModel;
using SimpleExampleRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleMessages;
using Prism.Events;

namespace MasterDetail.ViewModels
{
   public  class MasterViewModel:IMasterViewModel
    {
        
            public String ViewModelName { get; set; }
        public DelegateCommand<object> MasterButton_Command { get; set; }

        private IEventAggregator eventAggregator;
           
            public MasterViewModel(SimpleExampleService service, IEventAggregator eventAggregator)
            {
                this.eventAggregator = eventAggregator;
                this.ViewModelName = service.GetNameForDetailViewModel();

            MasterButton_Command = new DelegateCommand<object>(MasterButtonCommand_Handler);

             }

        private void MasterButtonCommand_Handler(object commandParameter)
        {
            /*( SimpleExampleRepository.SimpleExampleRepository repository = new SimpleExampleRepository.SimpleExampleRepository();
             SimpleExampleService service=new SimpleExampleService(repository);
             this.MasterNewName(service, 1);*/

            eventAggregator.GetEvent<ChangeLabelEvent>().Publish(commandParameter.ToString());
            

        }



    }

}
     /*   public void MasterNewName(SimpleExampleService service,int n)
        {
            this.ViewModelName = service.GetNewName();

            this.ViewModelName = "";

        }*/
