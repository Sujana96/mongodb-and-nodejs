﻿using SimpleExampleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleMessages;
using Prism.Events;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MasterDetail.ViewModels
{
    public class DetailViewModel : IDetailViewModel, INotifyPropertyChanged
    {
        private IEventAggregator eventAggregator;
      //  public String ViewModelName { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
       private string viewModelName;
        public string ViewModelName
        {
            get { return viewModelName; }
            set
            {
                if (viewModelName != value)
                {
                    viewModelName = value;
                    NotifyPropertyChanged();
                }
            }
        }

        protected void NotifyPropertyChanged([CallerMemberName]string caller = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(caller));
            }
        }

        public DetailViewModel(SimpleExampleService service, IEventAggregator eventAggregator)
        {
            this.eventAggregator = eventAggregator;
            this.ViewModelName = service.GetNameForDetailViewModel();
            this.eventAggregator.GetEvent<ChangeLabelEvent>().Subscribe(onChangeLabelEvent);
        }
        private void onChangeLabelEvent(string msg)
        {
            ViewModelName = msg;
        }


    }
}
