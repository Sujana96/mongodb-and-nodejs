﻿using Microsoft.Practices.ServiceLocation;
using Prism.Modularity;
using Prism.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using MasterDetail.ViewModels;
using MasterDetail.Views;
using Microsoft.Practices.Unity;
using SimpleExampleModel;
using SimpleExampleRepository;


namespace shell
{
    class Bootstrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            return ServiceLocator.Current.GetInstance<Shell>();
        }
        protected override void InitializeShell()
        {
            base.InitializeShell();
            var container = ServiceLocator.Current.GetInstance<IUnityContainer>();
            container.RegisterType<IMasterViewModel, MasterViewModel>();
            container.RegisterType<IDetailViewModel, DetailViewModel>();
            container.RegisterType<ISimpleExampleRepository, SimpleExampleRepository.SimpleExampleRepository>();
            container.RegisterType<ISimpleExampleService, SimpleExampleService>(new ContainerControlledLifetimeManager());


            Application.Current.MainWindow = (Window)this.Shell;
            Application.Current.MainWindow.Show();
        }

        protected override void ConfigureModuleCatalog()
        {
            base.ConfigureModuleCatalog();

            ModuleCatalog moduleCatalog = (ModuleCatalog)this.ModuleCatalog;
            moduleCatalog.AddModule(typeof(MasterDetail.MasterDetailModule));
        }
    }

}
