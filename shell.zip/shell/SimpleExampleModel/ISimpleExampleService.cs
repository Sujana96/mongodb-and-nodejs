﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleExampleModel
{
    public interface ISimpleExampleService
    {
        string GetNameForMasterViewModel();
        string GetNameForDetailViewModel();
     //   string GetNewName();
    }
}
