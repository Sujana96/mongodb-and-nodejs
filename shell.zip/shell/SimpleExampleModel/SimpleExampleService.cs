﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleExampleModel
{
    public class SimpleExampleService :ISimpleExampleService
    {
        private ISimpleExampleRepository repository;

        public SimpleExampleService(ISimpleExampleRepository repository)
        {
            this.repository = repository;
        }

        public string GetNameForMasterViewModel()
        {
            return repository.GetNameForMasterViewModel();
        }

        public string GetNameForDetailViewModel()
        {
            return repository.GetNameForDetailViewModel();
        }
      /*  public string GetNewName()
        {
            return repository.GetNewName();
        }*/
    }
}
