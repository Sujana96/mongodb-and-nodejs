﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleExampleModel;

namespace SimpleExampleRepository
{
    public class SimpleExampleRepository:ISimpleExampleRepository
    {
        public string GetNameForMasterViewModel()
        {
            return "SimpleExampleRepository.GetNameForMasterViewModel() returning 'MasterViewModel'";
        }

        public string GetNameForDetailViewModel()
        {
            return "SimpleExampleRepository.GetNameForDetailViewModel() returning 'DetailViewModel'";
        }

        public string GetNewName()
        {
            return "nikhil";
        }


    }
}
